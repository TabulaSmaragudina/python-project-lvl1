#!/usr/bin/env/python3

from brain_games.logic.progression_logic import progression_game


def main():
    progression_game()


if __name__ == '__main__':
    main()
