#!/usr/bin/env/python3

from brain_games.logic.gcd_logic import gcd_game


def main():
    gcd_game()


if __name__ == '__main__':
    main()
